
import React from "react";

export default function EstimationSalesPage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 p-8 space-y-10">
      <div className="text-center max-w-4xl mx-auto space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold">
          Fast. Accurate. Affordable Construction Estimates – Without the Overhead
        </h1>
        <p className="text-lg text-gray-600">
          Serving General Contractors, Subcontractors & Builders Across the U.S. With
          Lightning-Fast Takeoffs & Cost Estimates
        </p>
        <p className="text-xl font-medium text-green-600">
          ✅ Commercial | ✅ Residential | ✅ Public Works | ✅ All CSI Divisions
        </p>
        <div className="space-x-4">
          <button className="bg-blue-600 text-white px-6 py-3 rounded-xl text-lg">
            Request Estimate
          </button>
          <button className="border border-blue-600 text-blue-600 px-6 py-3 rounded-xl text-lg">
            Schedule a Call
          </button>
        </div>
      </div>
    </div>
  );
}
